package me.giantbee;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public final class GiantBeePlugin extends JavaPlugin implements Listener, CommandExecutor {

    private Bee boss;
    private BossBar bar;
    private int phase = 1;
    private long venomReady, rushReady, swarmReady, guardReady, wrathReady;
    private BukkitTask aiTask;

    private static final double MAX_HP = 300.0;

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("giantbee")).setExecutor(this);
        startAI();
        getLogger().info("GiantBee enabled.");
    }

    @Override
    public void onDisable() {
        removeBossBar();
        if (aiTask != null) aiTask.cancel();
    }

    private void startAI() {
        aiTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (boss == null || boss.isDead()) {
                if (boss != null) {
                    boss = null;
                    removeBossBar();
                }
                return;
            }

            updateBar();

            double hp = boss.getHealth();

            if (hp <= 210 && phase == 1) enterPhase(2);
            if (hp <= 120 && phase == 2) enterPhase(3);

            Player target = nearestPlayer(boss.getLocation(), 35);
            if (target == null) return;

            boss.setTarget(target);

            long now = System.currentTimeMillis();

            if (now >= venomReady && boss.getLocation().distanceSquared(target.getLocation()) <= 12 * 12) {
                venom(target);
                venomReady = now + 8000;
            }

            if (now >= rushReady && boss.getLocation().distanceSquared(target.getLocation()) > 36) {
                rush(target);
                rushReady = now + 12000;
            }

            if (phase >= 2 && now >= swarmReady) {
                swarm(target);
                swarmReady = now + 20000;
            }

            if (phase >= 2 && hp <= 180 && now >= guardReady) {
                guard();
                guardReady = now + 25000;
            }

            if (phase == 3 && now >= wrathReady) {
                wrathReady = now + 35000;
                wrath(target);
            }
        }, 20L, 20L);
    }

    private void spawnBoss(Player p) {
        if (boss != null && !boss.isDead()) {
            p.sendMessage(Component.text("A Giant Bee is already alive.", NamedTextColor.RED));
            return;
        }

        boss = p.getWorld().spawn(p.getLocation(), Bee.class);
        boss.customName(Component.text("GIANT BEE", NamedTextColor.GOLD));
        boss.setCustomNameVisible(true);
        boss.setMaxHealth(MAX_HP);
        boss.setHealth(MAX_HP);

        Attribute scale = Attribute.SCALE;
        if (boss.getAttribute(scale) != null) boss.getAttribute(scale).setBaseValue(3.0);

        if (boss.getAttribute(Attribute.MOVEMENT_SPEED) != null)
            boss.getAttribute(Attribute.MOVEMENT_SPEED).setBaseValue(0.55);

        boss.setPersistent(true);
        phase = 1;

        long now = System.currentTimeMillis();
        venomReady = rushReady = swarmReady = guardReady = wrathReady = now + 3000;

        bar = BossBar.bossBar(Component.text("GIANT BEE", NamedTextColor.GOLD),
                1.0f, BossBar.Color.YELLOW, BossBar.Overlay.PROGRESS);

        for (Player online : Bukkit.getOnlinePlayers()) online.showBossBar(bar);

        Bukkit.broadcast(Component.text("⚠ GIANT BEE HAS SPAWNED ⚠", NamedTextColor.GOLD));
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_BEE_HURT, 3f, 0.5f);
        p.getWorld().spawnParticle(Particle.FLAME, p.getLocation(), 60, 1.5, 1.5, 1.5, 0.05);
    }

    private void updateBar() {
        if (bar == null || boss == null) return;
        float progress = (float)Math.max(0, Math.min(1, boss.getHealth() / MAX_HP));
        bar.progress(progress);
    }

    private void enterPhase(int newPhase) {
        phase = newPhase;
        if (bar != null) {
            bar.color(newPhase == 2 ? BossBar.Color.YELLOW : BossBar.Color.RED);
            bar.name(Component.text(newPhase == 2 ? "GIANT BEE — PHASE 2" : "GIANT BEE — FINAL PHASE",
                    newPhase == 2 ? NamedTextColor.GOLD : NamedTextColor.RED));
        }
        Location l = boss.getLocation();
        l.getWorld().playSound(l, Sound.ENTITY_BEE_HURT, 4f, 0.35f);
        l.getWorld().spawnParticle(Particle.FLAME, l, newPhase == 2 ? 80 : 140, 2, 2, 2, 0.08);
        Bukkit.broadcast(Component.text(newPhase == 2
                ? "GIANT BEE entered PHASE 2!"
                : "⚠ GIANT BEE entered FINAL PHASE ⚠",
                newPhase == 2 ? NamedTextColor.GOLD : NamedTextColor.RED));
    }

    private Player nearestPlayer(Location from, double range) {
        Player best = null;
        double bestDist = range * range;
        for (Player p : from.getWorld().getPlayers()) {
            double d = from.distanceSquared(p.getLocation());
            if (d < bestDist && !p.isDead()) {
                best = p;
                bestDist = d;
            }
        }
        return best;
    }

    private void venom(Player target) {
        target.damage(5.0, boss);
        target.addPotionEffect(new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.POISON, 100, 0));
        target.addPotionEffect(new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.SLOWNESS, 60, 0));
        target.sendActionBar(Component.text("VENOM STING!", NamedTextColor.DARK_GREEN));
        target.getWorld().playSound(target.getLocation(), Sound.ENTITY_BEE_STING, 2f, 0.8f);
        target.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, target.getLocation(), 25, .5, 1, .5);
    }

    private void rush(Player target) {
        Vector v = target.getLocation().toVector().subtract(boss.getLocation().toVector()).normalize().multiply(1.8);
        boss.setVelocity(v);
        target.sendActionBar(Component.text("BEE RUSH!", NamedTextColor.YELLOW));

        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (boss != null && !boss.isDead() &&
                    boss.getLocation().distanceSquared(target.getLocation()) <= 36) {
                target.damage(8.0, boss);
                target.setVelocity(target.getLocation().toVector()
                        .subtract(boss.getLocation().toVector()).normalize().multiply(1.2).setY(0.6));
                target.getWorld().spawnParticle(Particle.CLOUD, target.getLocation(), 40, 1, 1, 1, .05);
            }
        }, 20L);
    }

    private void swarm(Player target) {
        if (boss == null || boss.isDead()) return;
        Bukkit.broadcast(Component.text("GIANT BEE summoned a SWARM!", NamedTextColor.YELLOW));

        for (int i = 0; i < 4; i++) {
            Bee bee = boss.getWorld().spawn(boss.getLocation(), Bee.class);
            bee.customName(Component.text("Swarm Bee", NamedTextColor.YELLOW));
            bee.setCustomNameVisible(false);
            bee.setMaxHealth(12);
            bee.setHealth(12);
            bee.setTarget(target);
        }
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_BEE_LOOP, 3f, 1.5f);
    }

    private void guard() {
        if (boss == null || boss.isDead()) return;
        Bukkit.broadcast(Component.text("ROYAL GUARD!", NamedTextColor.GOLD));

        boss.addPotionEffect(new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.RESISTANCE, 120, 3));
        boss.addPotionEffect(new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.REGENERATION, 120, 2));

        boss.getWorld().spawnParticle(Particle.ENCHANT, boss.getLocation(), 100, 2, 2, 2, .5);
    }

    private void wrath(Player target) {
        if (boss == null || boss.isDead()) return;
        Bukkit.broadcast(Component.text("⚠ QUEEN'S WRATH ⚠", NamedTextColor.DARK_RED));
        Location center = boss.getLocation();

        center.getWorld().spawnParticle(Particle.FLAME, center, 180, 3, 3, 3, .08);
        center.getWorld().playSound(center, Sound.ENTITY_WITHER_SPAWN, 2f, 1.4f);

        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (boss == null || boss.isDead()) return;
            for (Player p : center.getWorld().getPlayers()) {
                if (p.getLocation().distanceSquared(center) <= 144) {
                    p.damage(12.0, boss);
                    p.setVelocity(new Vector(0, 1.2, 0));
                    p.addPotionEffect(new org.bukkit.potion.PotionEffect(
                            org.bukkit.potion.PotionEffectType.POISON, 120, 1));
                    p.addPotionEffect(new org.bukkit.potion.PotionEffect(
                            org.bukkit.potion.PotionEffectType.WEAKNESS, 100, 0));
                    p.getWorld().spawnParticle(Particle.EXPLOSION, p.getLocation(), 10);
                }
            }
        }, 40L);
    }

    private void removeBossBar() {
        if (bar != null) {
            for (Player p : Bukkit.getOnlinePlayers()) p.hideBossBar(bar);
            bar = null;
        }
    }

    private void reward(Location location) {
        for (Player p : location.getWorld().getPlayers()) {
            if (p.getLocation().distanceSquared(location) > 625) continue;

            p.giveExp(30);
            p.getInventory().addItem(new org.bukkit.inventory.ItemStack(Material.HONEYCOMB, 8));
            p.getInventory().addItem(new org.bukkit.inventory.ItemStack(Material.GOLD_INGOT, 4));

            p.sendMessage(Component.text("BOSS REWARD: 8 Honeycomb + 4 Gold + 30 XP", NamedTextColor.GOLD));

            if (Math.random() < 0.15) {
                p.getInventory().addItem(new org.bukkit.inventory.ItemStack(Material.BEE_SPAWN_EGG, 1));
                p.sendMessage(Component.text("RARE DROP: Bee Spawn Egg!", NamedTextColor.LIGHT_PURPLE));
            }

            if (Math.random() < 0.05) {
                p.getInventory().addItem(new org.bukkit.inventory.ItemStack(Material.HONEY_BLOCK, 1));
                p.sendMessage(Component.text("LEGENDARY DROP: Honey Block!", NamedTextColor.GOLD));
            }
        }
    }

    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        if (!(e.getEntity() instanceof Bee bee) || boss == null || bee != boss) return;

        e.getDrops().clear();
        e.setDroppedExp(0);

        Location l = bee.getLocation();
        removeBossBar();
        boss = null;
        phase = 1;

        l.getWorld().spawnParticle(Particle.FIREWORK, l, 120, 2, 2, 2, .1);
        l.getWorld().playSound(l, Sound.UI_TOAST_CHALLENGE_COMPLETE, 3f, 1f);
        Bukkit.broadcast(Component.text("✦ GIANT BEE DEFEATED ✦", NamedTextColor.GOLD));
        reward(l);
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player player)) return;
        if (!(e.getDamager() instanceof Bee bee)) return;
        if (boss == bee && Math.random() < 0.25) {
            player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.POISON, 60, 0));
            player.sendActionBar(Component.text("VENOM!", NamedTextColor.DARK_GREEN));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (bar != null && boss != null && !boss.isDead()) e.getPlayer().showBossBar(bar);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (!player.hasPermission("giantbee.admin")) {
            player.sendMessage(Component.text("You don't have permission.", NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(Component.text("/giantbee spawn | kill | info", NamedTextColor.YELLOW));
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "spawn" -> spawnBoss(player);
            case "kill" -> {
                if (boss != null && !boss.isDead()) boss.remove();
                boss = null;
                removeBossBar();
                player.sendMessage(Component.text("Giant Bee removed.", NamedTextColor.RED));
            }
            case "info" -> {
                player.sendMessage(Component.text("GIANT BEE — 300 HP — 3x Scale", NamedTextColor.GOLD));
                player.sendMessage(Component.text("Phase 1: Venom + Rush", NamedTextColor.YELLOW));
                player.sendMessage(Component.text("Phase 2: Swarm + Royal Guard", NamedTextColor.GOLD));
                player.sendMessage(Component.text("Phase 3: Queen's Wrath", NamedTextColor.RED));
            }
            default -> player.sendMessage(Component.text("/giantbee spawn | kill | info", NamedTextColor.YELLOW));
        }
        return true;
    }
}
